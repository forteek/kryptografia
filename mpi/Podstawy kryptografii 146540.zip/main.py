from typing import Generator
from math import gcd
from rich import print as rprint
import re
import sys

DEBUG = False


def are_coprime(a: int, b: int) -> bool:
    return gcd(a, b) == 1


class SymmetricEncrypter:
    @staticmethod
    def encrypt(key, message) -> str:
        return ''.join([str(int(key_char) ^ int(message_char)) for key_char, message_char in zip(key, message)])

    @staticmethod
    def decrypt(key, message) -> str:
        return SymmetricEncrypter.encrypt(key, message)


class BbsGenerator:
    @staticmethod
    def generate(modulus: int, length: int, seed: int) -> Generator[int, None, None]:
        if not are_coprime(modulus, seed):
            raise AttributeError("Seed and modulus must be coprime.")

        number = seed
        for _ in range(length):
            number = (number ** 2) % modulus
            yield number % 2

class FipsTester:
    @staticmethod
    def single_bits_test(sequence: str) -> bool:
        if DEBUG:
            print(str(len(['1' for x in sequence if x == '1'])) + ' jedynek')

        return 9725 < len(['1' for x in sequence if x == '1']) < 10275

    @staticmethod
    def series_test(sequence: str) -> bool:
        return FipsTester._char_series_test(sequence, '0') and FipsTester._char_series_test(sequence, '1')

    @staticmethod
    def _char_series_test(sequence: str, char: str) -> bool:
        subsequences = re.findall(r"(" + char + r"+)", sequence)
        subsequences_counts = {x: 0 for x in range(1, 7)}

        for subsequence in subsequences:
            index = len(subsequence)
            index = index if index < 7 else 6

            subsequences_counts[index] += 1

        if DEBUG:
            print(f'Wystąpienia {char}: {subsequences_counts}')

        return 2315 < subsequences_counts[1] < 2685 and \
               1114 < subsequences_counts[2] < 1386 and \
               527 < subsequences_counts[3] < 723 and \
               240 < subsequences_counts[4] < 384 and \
               103 < subsequences_counts[5] < 209 and \
               103 < subsequences_counts[6] < 209

    @staticmethod
    def long_series_test(sequence: str) -> bool:
        long_sequences = re.findall(r"(1{26,}|0{26,})", sequence)

        if DEBUG:
            print(str(len(long_sequences)) + ' długich ciągów')

        return len(long_sequences) == 0

    @staticmethod
    def poker_test(sequence: str) -> bool:
        subsequences = [sequence[i:i+4] for i in range(0, len(sequence), 4)]
        frequencies = {x: 0 for x in range(16)}
        for subsequence in subsequences:
            frequencies[int(subsequence, 2)] += 1

        sum = 0
        for frequency in frequencies.values():
            sum += frequency ** 2

        result = 16/5000 * sum - 5000

        if DEBUG:
            print('Wynik testu pokerowego to ' + str(result))

        return 2.16 < result < 46.17

def test_sequence(seq: str) -> None:
    rprint('[bold blue]Test suite[/bold blue]')
    rprint('[white dim]Single bits test'.ljust(100, '.') + '[/white dim]', FipsTester.single_bits_test(seq))
    rprint('[white dim]Series test'.ljust(100, '.') + '[/white dim]', FipsTester.series_test(seq))
    rprint('[white dim]Long series test'.ljust(100, '.') + '[/white dim]', FipsTester.long_series_test(seq))
    rprint('[white dim]Poker test'.ljust(100, '.') + '[/white dim]', FipsTester.poker_test(seq))


if __name__ == '__main__':
    if len(sys.argv) > 1:
        with open(sys.argv[1], 'r') as f:
            seq = f.read().strip()
            if len(seq) > 20000:
                rprint('[bold yellow]Warning:[/bold yellow] Sequence is too long. It will be truncated to 20000 bits.\n')
                seq = seq[:20000]
            elif len(seq) < 20000:
                rprint('[bold red]Error:[/bold red] Sequence is too short. It needs to be 20000 bits long.')
                exit(1)
    else:
        seq = ''.join([str(x) for x in BbsGenerator.generate(1200000003730000000273, 20000, 5667298754)])

    rprint(f"[bold blue]Sequence:[/bold blue]")
    print(seq, '\n')

    rprint('Press [bold red]Enter[/bold red] to start tests.')
    input()

    test_sequence(seq)

    rprint('\nPress [bold red]Enter[/bold red] to start encryption.')
    input()

    while True:
        message = input('Enter message to encrypt: ')
        chars = set(message)
        if chars == {'0', '1'} or chars == {'0'} or chars == {'1'}:
            break

        rprint('Message must contain only [yellow]0s[/yellow] and [yellow]1s[/yellow].\n')

    key = BbsGenerator.generate(1200000003730000000273, len(message), 5667298754)

    rprint(f'\nMessage prior to encryption: [bold blue]{message}[/bold blue]')
    encrypted = SymmetricEncrypter.encrypt(key, message)
    rprint(f'Message after encryption:    [bold blue]{encrypted}[/bold blue]')
    decrypted = SymmetricEncrypter.decrypt(seq, encrypted)
    rprint(f'Message after decryption:    [bold blue]{decrypted}[/bold blue]')

    rprint('\nPress [bold red]Enter[/bold red] to start tests on multiple instances.')
    input()

    bbs_seeds = [
        (1200000003730000000273, 5667298754),
        (1200000003730000000273, 2921799738),
        (1200000003730000000273, 5861968144),
    ]

    for modulus, seed in bbs_seeds:
        seq = ''.join([str(x) for x in BbsGenerator.generate(modulus, 20000, seed)])

        rprint(f"[bold blue]Sequence:[/bold blue]")
        print(seq, '\n')

        test_sequence(seq)

        rprint('\nPress [bold red]Enter[/bold red] to continue.')
        input()

    rprint('\nPress [bold red]Enter[/bold red] to start tests on a random encrypted value.')
    input()

    modulus, seed = bbs_seeds[0]
    key = ''.join([str(x) for x in BbsGenerator.generate(modulus, 20000, seed)])
    modulus, seed = bbs_seeds[1]
    message = ''.join([str(x) for x in BbsGenerator.generate(modulus, 20000, seed)])

    encrypted = SymmetricEncrypter.encrypt(key, message)

    rprint(f"[bold blue]Sequence:[/bold blue]")
    print(encrypted, '\n')

    test_sequence(encrypted)

    rprint('\nPress [bold red]Enter[/bold red] to start generating a 1 million bits long sequence.')
    input()

    modulus, seed = bbs_seeds[2]
    seq = ''.join([str(x) for x in BbsGenerator.generate(modulus, 1_000_000, seed)])

    with open('result', 'w') as file:
        file.write(seq)

    rprint('Sequence saved to [bold blue]result[/bold blue] file.')

    rprint('\nPress [bold red]Enter[/bold red] to exit.')
    input()
